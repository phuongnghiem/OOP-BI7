package tutorial;

import java.awt.FlowLayout;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import javax.swing.*;

public class Test extends JFrame {
    private JLabel namelabel,idlabel,tuitionlabel;
    private JTextField namefield,idfield,tuitionfield;
    private JCheckBox checkdiscount;
    private JButton done,list;
    private String Name, ID, Discount="0";
    private int TuitionFee;
    public String getID(){
        return ID;
    }
    public int getTuitionFee(){
        return TuitionFee;
    }
    public String getName(){
        return Name;
    }
    public String getDiscount(){ return Discount;}

    public Test() {
        super("Tuition form");
        setLayout(new FlowLayout());
        namelabel = new JLabel("Full name:");
        add(namelabel);
        namefield = new JTextField(20);
        add(namefield);

        idlabel = new JLabel("ID:");
        add(idlabel);
        idfield = new JTextField(11);
        add(idfield);

        tuitionlabel = new JLabel("Basic fee:");
        add(tuitionlabel);
        tuitionfield = new JTextField(8);
        add(tuitionfield);

        checkdiscount = new JCheckBox("Check this box if you have discounted tuition fee");
        add(checkdiscount);
        done = new JButton("Pay");
        add(done);
        list = new JButton("View Student List");
        add(list);

        thehandler handler = new thehandler();
        checkdiscount.addActionListener(handler);
        done.addActionListener(handler);
        list.addActionListener(handler);
    }

    private class thehandler implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            if (e.getSource() == checkdiscount) {
                Discount=JOptionPane.showInputDialog(null,"How many percent?");
            }
            if (e.getSource() == done) {
                PrintWriter print = null;
                Name = namefield.getText();
                TuitionFee = Integer.parseInt(tuitionfield.getText());
                ID = idfield.getText();

                TuitionFee -= TuitionFee * Integer.parseInt(Discount)/100;
                JOptionPane.showMessageDialog(null, "Completedly! Thanks for paying. Your final tuition fee is: " + TuitionFee);

                try{
                    print = new PrintWriter(new FileWriter("C:\\Users\\Dell E6420\\Desktop\\Studentlist.txt",true));
                }catch(IOException x){
                    x.printStackTrace();
                }
                print.println( "\n" + getName() + "\t" + getID() + "\t" + getDiscount() + "\t" +  getTuitionFee());
                print.close();
            }
            if(e.getSource() == list){
                try{
                    if ((new File("C:\\Users\\Dell E6420\\Desktop\\Studentlist.txt")).exists()) {
                        Process p = Runtime
                                .getRuntime()
                                .exec("rundll32 url.dll,FileProtocolHandler C:\\Users\\Dell E6420\\Desktop\\Studentlist.txt");
                        p.waitFor();
                    } else {
                        System.out.println("File does not exist");
                    }
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        }
    }
}