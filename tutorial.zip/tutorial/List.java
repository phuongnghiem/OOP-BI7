package tutorial;

import javax.swing.*;
import java.awt.*;


public class List extends JFrame{
    private JTable jt;

    String[] column_headers={"Name","ID","Tuition Fee"};
    String[][] studentInformation={{"a","b","c"},{"c","d","e"}};

    public List(){
        super("Student List");
        jt = new JTable(studentInformation,column_headers);
        jt.setBounds(50,50,400,400);
        JScrollPane js=new JScrollPane(jt);
        this.add(js);
        this.setSize(300,400);
        this.setVisible(true);
    }


}
