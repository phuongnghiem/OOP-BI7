package tutorial;

import javax.swing.*;

class Quy{
    public static void main(String args[]){
        Test quydepzai = new Test();
        quydepzai.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        quydepzai.setSize(700,100);
        quydepzai.setLocation(500,100);
        quydepzai.setVisible(true);

    }
}