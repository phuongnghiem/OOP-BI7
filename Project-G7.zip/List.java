package tutorial;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.Vector;


public class List extends JFrame {
    private JTable jt;

    public List() {
        Scanner read = null;

        try {
            read = new Scanner(new File("C:\\Users\\Dell E6420\\Desktop\\Studentlist.txt"));
        } catch (FileNotFoundException x) {
            System.out.println("ERROR!!!!");
        }

        String a,b,c,d,e,f,g,h,i,j,k,l,m,n,p,q,u,y;

        while (read.hasNext()) {
            a = read.next(); b = read.next(); c = read.next(); d = read.next(); e = read.next();
            f = read.next(); g = read.next(); h = read.next(); i = read.next();
            j = read.next(); k = read.next(); l = read.next(); m = read.next(); n = read.next();
            p = read.next(); q = read.next(); u = read.next(); y = read.next();

            String[] column_headers = {"Name", "ID", "Tuition Fee"};
            Object[][] studentInformation = {{a, b, c},{d,e,f},{g,h,i},{j, k, l},{m,n,p},{q,u,y}};

            jt = new JTable(studentInformation, column_headers);
            JScrollPane js = new JScrollPane(jt);
            this.add(js);
            this.setBounds(250,250,500,250);
            this.setVisible(true);
        }
        read.close();
    }
}
