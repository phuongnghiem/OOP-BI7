package tutorial;

import javax.swing.*;

class Quy{
    public static void main(String args[]){
        Test a = new Test();
        a.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        a.setSize(700,100);
        a.setLocation(500,100);
        a.setVisible(true);
    }
}