package tutorial;

import java.awt.FlowLayout;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import javax.swing.*;

public class Test extends JFrame {

    // Create label "Full name" , "ID", "Basic Fee"
    private JLabel namelabel,idlabel,tuitionlabel;

    // Create text field of name,id,basic fee
    private JTextField namefield,idfield,tuitionfield;

    // Create checkbox to check discount
    private JCheckBox checkdiscount;

    // Create button "Add" , "View Student List"
    private JButton done,list;

    // Declare variables
    private String Name, ID, Discount;
    private int TuitionFee;

    // Method
    public String getID(){
        return ID;
    }
    public int getTuitionFee(){
        return TuitionFee;
    }
    public String getName(){
        return Name;
    }
    public String getDiscount(){ return Discount;}


    // Constructor
    public Test() {
        super("Tuition form");

        Discount = "0"; // Initialize

        // Choose Flow layout
        setLayout(new FlowLayout());

        //Initialize variable
        namelabel = new JLabel("Full name:");
        add(namelabel);
        namefield = new JTextField(20);
        add(namefield);

        idlabel = new JLabel("ID:");
        add(idlabel);
        idfield = new JTextField(11);
        add(idfield);

        tuitionlabel = new JLabel("Basic fee:");
        add(tuitionlabel);
        tuitionfield = new JTextField(8);
        add(tuitionfield);

        checkdiscount = new JCheckBox("Check this box for discounted tuition fee");
        add(checkdiscount);
        done = new JButton("Add");
        add(done);
        list = new JButton("View Student List");
        add(list);

        // Add listener
        thehandler handler = new thehandler();
        checkdiscount.addActionListener(handler);
        done.addActionListener(handler);
        list.addActionListener(handler);
    }


    // Add method for each button
    private class thehandler implements ActionListener {

        public void actionPerformed(ActionEvent e) {

            // Discount
            if (e.getSource() == checkdiscount) {
                Discount=JOptionPane.showInputDialog(null,"How many percent?");
            }

            // Add Student information in file " Studentlist.txt "
            if (e.getSource() == done) {
                PrintWriter print = null;
                Name = namefield.getText();
                TuitionFee = Integer.parseInt(tuitionfield.getText());
                ID = idfield.getText();

                TuitionFee -= TuitionFee * Integer.parseInt(Discount)/100;
                JOptionPane.showMessageDialog(null, "Add information successfully! Final tuition fee is : " + TuitionFee);

                try{
                    print = new PrintWriter(new FileWriter("C:\\Users\\Dell E6420\\Desktop\\Studentlist.txt",true));
                }catch(IOException x){
                    System.out.print("Can not write!");
                }
                print.println( "\n" + getName() + "\t" + getID() + "\t" + getDiscount() + "\t" +  getTuitionFee());
                print.close();
            }

            // Open the file "Studentlist.txt"
            if(e.getSource() == list){
                try{
                    if ((new File("C:\\Users\\Dell E6420\\Desktop\\Studentlist.txt")).exists()) {
                        Process c = Runtime.getRuntime().exec("rundll32 url.dll,FileProtocolHandler C:\\Users\\Dell E6420\\Desktop\\Studentlist.txt");
                        c.waitFor();
                    } else {
                        System.out.println("File does not exist");
                    }
                } catch (Exception x) {
                    System.out.print("Can not read !");
                }

                // GUI of "View Student List" - have not been completed yet.
//                new List();
            }
        }
    }
}
